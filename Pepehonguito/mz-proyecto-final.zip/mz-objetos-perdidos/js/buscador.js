// ============================================================
//  js/buscador.js - Pantalla 05: buscador en tiempo real
// ============================================================

const cajaBuscar = document.getElementById('buscar');
const resultadosBuscar = document.getElementById('resultados');

function buscar() {
  const texto = cajaBuscar.value.toLowerCase().trim();
  const lista = obtenerObjetos();
  const encontrados = [];

  for (let i = 0; i < lista.length; i++) {
    const o = lista[i];
    const todo = (o.titulo + ' ' + o.ubicacion + ' ' + o.codigo + ' ' + o.categoria).toLowerCase();
    if (todo.includes(texto)) {
      encontrados.push(o);
    }
  }
  dibujarTarjetas(encontrados, resultadosBuscar);
}

cajaBuscar.addEventListener('keyup', buscar);   // se ejecuta con cada letra escrita
buscar();
