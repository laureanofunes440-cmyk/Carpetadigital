// ============================================================
//  js/menu.js - Dibuja el menú lateral y protege las pantallas
//  Cada HTML tiene <body data-pagina="03"> con su número de pantalla
// ============================================================

// Pantallas que aparecen en el menú
const ENLACES_MENU = [
  { numero: '03', texto: 'Muro principal', archivo: '03-muro.html' },
  { numero: '05', texto: 'Buscador', archivo: '05-buscador.html' },
  { numero: '06', texto: 'Filtros y categorías', archivo: '06-filtros.html' },
  { numero: '07', texto: 'Reportar perdido', archivo: '07-perdido-basicos.html' },
  { numero: '11', texto: 'Reportar hallazgo', archivo: '11-encontre-basicos.html' },
  { numero: '15', texto: 'Notificaciones', archivo: '15-notificaciones.html' },
  { numero: '16', texto: 'Coordinar entrega', archivo: '16-chat.html' },
  { numero: '17', texto: 'Marcar recuperado', archivo: '17-recuperado.html' },
  { numero: '18', texto: 'Mi perfil', archivo: '18-perfil.html' },
  { numero: '19', texto: 'Ayuda', archivo: '19-ayuda.html' },
  { numero: '20', texto: 'Panel de Preceptoría', archivo: '20-preceptoria.html' }
];

// Agrupa de qué pantalla "cuelga" cada paso (para marcar el menú activo)
const MENU_DE = { '04': '03', '08': '07', '09': '07', '10': '07', '12': '11', '13': '11', '14': '11' };

function dibujarMenu() {
  const pagina = document.body.dataset.pagina;
  const correo = obtenerUsuario();

  // Sin sesión solo se pueden ver las pantallas 01 y 02
  if (correo === null && Number(pagina) > 2) {
    window.location.href = '02-login.html';
    return;
  }
  // La pantalla 20 es solo para preceptores
  if (pagina === '20' && !esPreceptor(correo)) {
    window.location.href = '03-muro.html';
    return;
  }

  const menu = document.getElementById('menu');
  menu.innerHTML = '<a class="logo" href="01-bienvenida.html"><b>MZ</b> Objetos Perdidos</a>';

  const activa = MENU_DE[pagina] || pagina;
  for (let i = 0; i < ENLACES_MENU.length; i++) {
    const item = ENLACES_MENU[i];
    // El enlace de preceptoría solo lo ve un preceptor
    if (item.numero === '20' && !esPreceptor(correo)) {
      continue;
    }
    const enlace = document.createElement('a');
    enlace.className = 'enlace' + (item.numero === activa ? ' activo' : '');
    enlace.href = item.archivo;
    enlace.textContent = item.texto;
    menu.appendChild(enlace);
  }

  // Botón para cerrar sesión (solo si hay sesión iniciada)
  if (correo !== null) {
    const boton = document.createElement('button');
    boton.textContent = 'Cerrar sesión';
    boton.addEventListener('click', function () {
      localStorage.removeItem('usuario');
      window.location.href = '01-bienvenida.html';
    });
    menu.appendChild(boton);
  }
}

dibujarMenu();
