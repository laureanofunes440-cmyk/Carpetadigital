// ============================================================
//  js/filtros.js - Pantalla 06: filtros por categoría, estado y fecha
// ============================================================

const filtroCategoria = document.getElementById('filtro-categoria');
const filtroEstado = document.getElementById('filtro-estado');
const filtroFecha = document.getElementById('filtro-fecha');
const resultadosFiltro = document.getElementById('resultados');

function filtrar() {
  const lista = obtenerObjetos();
  const encontrados = [];

  for (let i = 0; i < lista.length; i++) {
    const o = lista[i];
    if (filtroCategoria.value !== '' && o.categoria !== filtroCategoria.value) { continue; }
    if (filtroEstado.value !== '' && o.estado !== filtroEstado.value) { continue; }
    if (filtroFecha.value !== '' && o.fecha < filtroFecha.value) { continue; }
    encontrados.push(o);
  }
  dibujarTarjetas(encontrados, resultadosFiltro);
}

filtroCategoria.addEventListener('change', filtrar);
filtroEstado.addEventListener('change', filtrar);
filtroFecha.addEventListener('change', filtrar);
filtrar();
