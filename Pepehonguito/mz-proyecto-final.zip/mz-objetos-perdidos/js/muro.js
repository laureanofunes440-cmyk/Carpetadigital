// ============================================================
//  js/muro.js - Pantalla 03: muro de objetos
//  Pide los objetos al servidor con fetch() y los dibuja manipulando el DOM
// ============================================================

const URL_OBJETOS = 'http://127.0.0.1:3000/api/objetos';
const contenedorMuro = document.getElementById('muro');

// Arma la tarjeta de UN objeto con el DOM (createElement y appendChild)
function crearTarjetaMuro(objeto) {
  const tarjeta = document.createElement('article');
  tarjeta.className = 'objeto';

  // "Foto": un emoji según la categoría (viene de nuestro propio listado, es seguro)
  const foto = document.createElement('div');
  foto.className = 'foto';
  foto.innerHTML = ICONOS[objeto.categoria] || '📦';

  const estado = document.createElement('span');
  estado.className = 'estado ' + objeto.estado;
  estado.textContent = objeto.estado;

  // textContent para los textos escritos por personas (evita que se interpreten como HTML)
  const titulo = document.createElement('h3');
  titulo.textContent = objeto.titulo;

  const datos = document.createElement('small');
  datos.textContent = objeto.categoria + ' · ' + formatearFecha(objeto.fecha);

  const boton = document.createElement('button');
  boton.className = 'boton';
  boton.textContent = 'Ver detalles';
  // BOM: window.location.href lleva a la pantalla 04 con el id del objeto
  boton.addEventListener('click', function () {
    window.location.href = '04-detalle.html?id=' + objeto.id;
  });

  tarjeta.appendChild(foto);
  tarjeta.appendChild(estado);
  tarjeta.appendChild(titulo);
  tarjeta.appendChild(datos);
  tarjeta.appendChild(boton);
  return tarjeta;
}

// Pide la lista al servidor y la muestra
async function cargarMuro() {
  contenedorMuro.innerHTML = '<p>Cargando objetos…</p>';

  try {
    const respuesta = await fetch(URL_OBJETOS);
    if (!respuesta.ok) {
      throw new Error('El servidor respondió con el código ' + respuesta.status);
    }
    const objetos = await respuesta.json();

    contenedorMuro.innerHTML = '';   // borramos el mensaje "Cargando…"
    if (objetos.length === 0) {
      contenedorMuro.innerHTML = '<p>Todavía no hay objetos publicados.</p>';
      return;
    }
    for (let i = 0; i < objetos.length; i++) {
      contenedorMuro.appendChild(crearTarjetaMuro(objetos[i]));
    }
  } catch (error) {
    contenedorMuro.innerHTML = '<p class="error">No se pudo conectar con el servidor. ¿Ejecutaste "node server.js"?</p>';
    console.log('Error al cargar el muro: ' + error.message);
  }
}

cargarMuro();
