// ============================================================
//  js/datos.js - Datos de prueba y funciones para guardarlos
//  Sin servidor: los datos se guardan en el navegador (localStorage)
// ============================================================

// Objetos de prueba (se usan la primera vez que se abre el sitio)
const OBJETOS_PRUEBA = [
  { codigo: 'MZ-P-0001', titulo: 'Calculadora científica Casio', categoria: 'Útiles', estado: 'Perdido', ubicacion: 'Aula 204', fecha: '2026-11-03', descripcion: 'Calculadora gris con tapa. Atrás tiene mi nombre.' },
  { codigo: 'MZ-E-0001', titulo: 'Campera roja y negra', categoria: 'Indumentaria', estado: 'Encontrado', ubicacion: 'Laboratorio de Química', fecha: '2026-11-04', descripcion: 'Campera rompevientos talle L. Estaba en el último banco.' },
  { codigo: 'MZ-E-0002', titulo: 'Auriculares blancos', categoria: 'Tecnología', estado: 'Encontrado', ubicacion: 'Biblioteca', fecha: '2026-11-05', descripcion: 'Auriculares inalámbricos con su estuche de carga.' },
  { codigo: 'MZ-P-0002', titulo: 'Termo verde de 1 litro', categoria: 'Varios', estado: 'Perdido', ubicacion: 'Gradas del playón', fecha: '2026-11-05', descripcion: 'Termo verde con manija y stickers de bandas de rock.' },
  { codigo: 'MZ-E-0003', titulo: 'Carpeta de Contabilidad III', categoria: 'Útiles', estado: 'Encontrado', ubicacion: 'Biblioteca', fecha: '2026-11-06', descripcion: 'Carpeta azul con apuntes y prácticos.' },
  { codigo: 'MZ-P-0003', titulo: 'Buzo azul con escudo', categoria: 'Indumentaria', estado: 'Perdido', ubicacion: 'Patio central', fecha: '2026-11-06', descripcion: 'Buzo azul marino talle M con el escudo del colegio.' },
  { codigo: 'MZ-E-0004', titulo: 'Llaves con llavero del escudo', categoria: 'Varios', estado: 'Encontrado', ubicacion: 'Portón de entrada', fecha: '2026-11-07', descripcion: 'Dos llaves doradas con un llavero azul.' },
  { codigo: 'MZ-P-0004', titulo: 'Mochila negra con pines', categoria: 'Varios', estado: 'Recuperado', ubicacion: 'Cantina', fecha: '2026-11-02', descripcion: 'Mochila negra de lona con tres pines metálicos.' }
];

// Un emoji para cada categoría (se usa como "foto" de la tarjeta)
const ICONOS = { 'Útiles': '✏️', 'Tecnología': '💻', 'Indumentaria': '🧥', 'Varios': '📦' };

// Devuelve la lista de objetos guardada; si no hay, guarda y devuelve los de prueba
function obtenerObjetos() {
  const guardados = localStorage.getItem('objetos');
  if (guardados === null) {
    guardarObjetos(OBJETOS_PRUEBA);
    return OBJETOS_PRUEBA;
  }
  return JSON.parse(guardados);
}

// Guarda la lista completa de objetos
function guardarObjetos(lista) {
  localStorage.setItem('objetos', JSON.stringify(lista));
}

// Correo de la persona que inició sesión (o null si no inició)
function obtenerUsuario() {
  return localStorage.getItem('usuario');
}

// Los preceptores usan un correo que empieza con "preceptor"
function esPreceptor(correo) {
  return correo !== null && correo.startsWith('preceptor');
}

// ------------------------------------------------------------
//  Funciones de ayuda que usan varias pantallas
// ------------------------------------------------------------

// Fecha de hoy con formato AAAA-MM-DD
function hoy() {
  const f = new Date();
  const mes = String(f.getMonth() + 1).padStart(2, '0');
  const dia = String(f.getDate()).padStart(2, '0');
  return f.getFullYear() + '-' + mes + '-' + dia;
}

// Busca un objeto por su código en una lista (devuelve null si no existe)
function buscarPorCodigo(lista, codigo) {
  for (let i = 0; i < lista.length; i++) {
    if (lista[i].codigo === codigo) {
      return lista[i];
    }
  }
  return null;
}

// Código nuevo: MZ-P-0005 para perdidos y MZ-E-0005 para encontrados
function generarCodigo(estado, lista) {
  const prefijo = estado === 'Perdido' ? 'MZ-P-' : 'MZ-E-';
  let cantidad = 0;
  for (let i = 0; i < lista.length; i++) {
    if (lista[i].codigo.startsWith(prefijo)) {
      cantidad++;
    }
  }
  return prefijo + String(cantidad + 1).padStart(4, '0');
}

// Lee un dato de la dirección, por ejemplo ?codigo=MZ-P-0001
function obtenerParametro(nombre) {
  const parametros = new URLSearchParams(window.location.search);
  return parametros.get(nombre);
}
