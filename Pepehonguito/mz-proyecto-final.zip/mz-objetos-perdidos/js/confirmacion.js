// ============================================================
//  js/confirmacion.js - Pantallas 10 y 14: muestra el código creado
// ============================================================

const codigoCreado = window.localStorage.getItem('ultimoCodigo');
const idCreado = window.localStorage.getItem('ultimoId');
document.getElementById('codigo').textContent = codigoCreado || 'Sin código';

// "Ver mi reporte" lleva al detalle con el id que devolvió el servidor
const enlaceReporte = document.getElementById('ver-reporte');
if (enlaceReporte && idCreado) {
  enlaceReporte.href = '04-detalle.html?id=' + idCreado;
}
