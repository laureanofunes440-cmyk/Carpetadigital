// ============================================================
//  js/chat.js - Pantalla 16: chat de coordinación de entrega
// ============================================================

const formularioChat = document.getElementById('formulario-chat');
const textoChat = document.getElementById('texto-chat');
const cajaMensajes = document.getElementById('mensajes');
const cajaObjetoChat = document.getElementById('objeto-chat');

// Si llegamos desde un objeto, mostramos su resumen
const objetoChat = buscarPorCodigo(obtenerObjetos(), obtenerParametro('codigo'));
if (objetoChat !== null) {
  cajaObjetoChat.textContent = 'Objeto: ' + objetoChat.titulo + ' (' + objetoChat.codigo + ')';
} else {
  cajaObjetoChat.hidden = true;
}

formularioChat.addEventListener('submit', function (evento) {
  evento.preventDefault();
  const texto = textoChat.value.trim();
  if (texto === '') { return; }

  cajaMensajes.appendChild(crearElemento('p', 'burbuja yo', texto));
  textoChat.value = '';

  // Respuesta automática de ejemplo, un segundo después
  setTimeout(function () {
    cajaMensajes.appendChild(crearElemento('p', 'burbuja otro', 'Gracias por tu mensaje. Un preceptor te responde pronto.'));
  }, 1000);
});
