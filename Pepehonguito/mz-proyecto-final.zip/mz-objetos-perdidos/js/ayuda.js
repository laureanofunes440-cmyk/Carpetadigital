// ============================================================
//  js/ayuda.js - Pantalla 19: buscador de preguntas frecuentes
// ============================================================

const cajaDudas = document.getElementById('dudas');
const preguntas = document.querySelectorAll('details');

cajaDudas.addEventListener('keyup', function () {
  const texto = cajaDudas.value.toLowerCase().trim();
  for (let i = 0; i < preguntas.length; i++) {
    const coincide = preguntas[i].textContent.toLowerCase().includes(texto);
    preguntas[i].style.display = coincide ? 'block' : 'none';
  }
});
