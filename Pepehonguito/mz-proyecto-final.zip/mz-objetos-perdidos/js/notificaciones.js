// ============================================================
//  js/notificaciones.js - Pantalla 15: marcar todo como leído
// ============================================================

const enlaceLeidas = document.getElementById('marcar-leidas');

enlaceLeidas.addEventListener('click', function (evento) {
  evento.preventDefault();
  const nuevas = document.querySelectorAll('.notificacion.nueva');
  for (let i = 0; i < nuevas.length; i++) {
    nuevas[i].classList.remove('nueva');
  }
});
