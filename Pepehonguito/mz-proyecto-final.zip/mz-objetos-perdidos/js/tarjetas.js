// ============================================================
//  js/tarjetas.js - Arma la tarjeta de un objeto
//  La usan el muro, el buscador y los filtros
// ============================================================

// Cambia 2026-11-03 por 03/11/2026
function formatearFecha(fecha) {
  const partes = fecha.split('-');
  return partes[2] + '/' + partes[1] + '/' + partes[0];
}

// Crea un elemento HTML con una clase y un texto
function crearElemento(etiqueta, clase, texto) {
  const elemento = document.createElement(etiqueta);
  if (clase) {
    elemento.className = clase;
  }
  if (texto) {
    elemento.textContent = texto;   // textContent evita que el texto se interprete como HTML
  }
  return elemento;
}

// Devuelve la tarjeta (un <article>) de un objeto
function crearTarjeta(objeto) {
  const tarjeta = crearElemento('article', 'objeto');

  tarjeta.appendChild(crearElemento('div', 'foto', ICONOS[objeto.categoria] || '📦'));
  tarjeta.appendChild(crearElemento('span', 'estado ' + objeto.estado, objeto.estado));
  tarjeta.appendChild(crearElemento('h3', '', objeto.titulo));
  tarjeta.appendChild(crearElemento('small', '', objeto.categoria + ' · ' + formatearFecha(objeto.fecha)));

  // El botón lleva a la pantalla 04 con el código del objeto en la dirección
  const boton = crearElemento('a', 'boton', 'Ver detalles');
  boton.href = '04-detalle.html?codigo=' + objeto.codigo;
  tarjeta.appendChild(boton);

  return tarjeta;
}

// Dibuja una lista de objetos dentro de un contenedor
function dibujarTarjetas(lista, contenedor) {
  contenedor.innerHTML = '';
  if (lista.length === 0) {
    contenedor.appendChild(crearElemento('p', '', 'No hay objetos para mostrar.'));
    return;
  }
  for (let i = 0; i < lista.length; i++) {
    contenedor.appendChild(crearTarjeta(lista[i]));
  }
}
