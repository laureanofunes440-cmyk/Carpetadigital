// ============================================================
//  ObjetoModel.js - Modelo (POO): todas las consultas SQL de "objetos"
//  Los métodos son estáticos: se usan sin crear instancias,
//  por ejemplo ObjetoModel.obtenerTodos(...)
// ============================================================

const conexion = require('./conexion');

class ObjetoModel {

  // SELECT: devuelve todos los objetos (los más nuevos primero)
  // callback(error, listaDeObjetos)
  static obtenerTodos(callback) {
    const sql = "SELECT id, codigo, titulo, categoria, estado, ubicacion, " +
                "DATE_FORMAT(fecha, '%Y-%m-%d') AS fecha, descripcion " +
                "FROM objetos ORDER BY fecha DESC, id DESC";

    conexion.query(sql, function (error, resultados) {
      callback(error, resultados);
    });
  }

  // INSERT: guarda un objeto nuevo y le asigna su código (MZ-P-... o MZ-E-...)
  // datos = { titulo, categoria, estado, ubicacion, fecha, descripcion }
  // callback(error, objetoGuardado)
  static crear(datos, callback) {
    const prefijo = datos.estado === 'Perdido' ? 'MZ-P-' : 'MZ-E-';

    // 1. Contamos cuántos códigos de ese tipo hay para saber el número siguiente
    const sqlContar = 'SELECT COUNT(*) AS total FROM objetos WHERE codigo LIKE ?';

    conexion.query(sqlContar, [prefijo + '%'], function (error, resultados) {
      if (error) {
        callback(error, null);
        return;
      }
      const numero = resultados[0].total + 1;
      const codigo = prefijo + String(numero).padStart(4, '0');   // ejemplo: MZ-P-0003

      // 2. Insertamos el objeto (cada ? se reemplaza por un valor, de forma segura)
      const sqlInsertar = 'INSERT INTO objetos (codigo, titulo, categoria, estado, ubicacion, fecha, descripcion) VALUES (?, ?, ?, ?, ?, ?, ?)';
      const valores = [codigo, datos.titulo, datos.categoria, datos.estado, datos.ubicacion, datos.fecha, datos.descripcion];

      conexion.query(sqlInsertar, valores, function (error, resultado) {
        if (error) {
          callback(error, null);
          return;
        }
        // 3. Devolvemos el objeto tal como quedó guardado
        callback(null, {
          id: resultado.insertId,
          codigo: codigo,
          titulo: datos.titulo,
          categoria: datos.categoria,
          estado: datos.estado,
          ubicacion: datos.ubicacion,
          fecha: datos.fecha,
          descripcion: datos.descripcion
        });
      });
    });
  }
}

module.exports = ObjetoModel;
