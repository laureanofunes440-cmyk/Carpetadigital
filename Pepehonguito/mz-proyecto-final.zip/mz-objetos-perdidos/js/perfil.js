// ============================================================
//  js/perfil.js - Pantalla 18: perfil del alumno
// ============================================================

const correoPerfil = obtenerUsuario();

// Armamos el nombre con el correo: laureano.funes@... -> Laureano Funes
const partesNombre = correoPerfil.split('@')[0].split('.');
let nombrePerfil = '';
let inicialesPerfil = '';
for (let i = 0; i < partesNombre.length; i++) {
  const palabra = partesNombre[i].charAt(0).toUpperCase() + partesNombre[i].substring(1);
  nombrePerfil += (i > 0 ? ' ' : '') + palabra;
  if (i < 2) {
    inicialesPerfil += palabra.charAt(0);
  }
}
document.getElementById('perfil-nombre').textContent = nombrePerfil;
document.getElementById('perfil-correo').textContent = correoPerfil;
document.getElementById('avatar').textContent = inicialesPerfil;

// Estadísticas con los reportes hechos desde este navegador
const misCodigosPerfil = JSON.parse(localStorage.getItem('misCodigos') || '[]');
const listaPerfil = obtenerObjetos();
const actividad = document.getElementById('actividad');
let recuperadosPerfil = 0;
let ayudasPerfil = 0;

for (let j = misCodigosPerfil.length - 1; j >= 0; j--) {
  const o = buscarPorCodigo(listaPerfil, misCodigosPerfil[j]);
  if (misCodigosPerfil[j].includes('-E-')) { ayudasPerfil++; }
  if (o !== null) {
    if (o.estado === 'Recuperado') { recuperadosPerfil++; }
    actividad.appendChild(crearElemento('li', '', o.codigo + ' · ' + o.titulo + ' (' + formatearFecha(o.fecha) + ')'));
  }
}
if (misCodigosPerfil.length === 0) {
  actividad.appendChild(crearElemento('li', '', 'Todavía no hiciste reportes.'));
}
document.getElementById('cifra-reportes').textContent = misCodigosPerfil.length;
document.getElementById('cifra-recuperados').textContent = recuperadosPerfil;
document.getElementById('cifra-ayudas').textContent = ayudasPerfil;
