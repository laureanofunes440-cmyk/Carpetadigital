// ============================================================
//  js/detalle.js - Pantalla 04: detalle de un objeto
//  Llega con el id en la dirección: 04-detalle.html?id=3
//  (si llega ?codigo=... busca en los datos guardados en el navegador)
// ============================================================

const URL_OBJETOS = 'http://127.0.0.1:3000/api/objetos';
const cajaDetalle = document.getElementById('detalle');

// Dibuja los datos del objeto en la pantalla
function mostrarDetalle(objeto) {
  cajaDetalle.innerHTML = '';
  if (objeto === null) {
    cajaDetalle.appendChild(crearElemento('p', '', 'No se encontró ese reporte.'));
    return;
  }

  cajaDetalle.appendChild(crearElemento('div', 'foto', ICONOS[objeto.categoria] || '📦'));
  cajaDetalle.appendChild(crearElemento('span', 'estado ' + objeto.estado, objeto.estado));
  cajaDetalle.appendChild(crearElemento('h2', '', objeto.titulo));
  cajaDetalle.appendChild(crearElemento('p', '', 'Código de seguimiento: ' + objeto.codigo));
  cajaDetalle.appendChild(crearElemento('p', '', 'Categoría: ' + objeto.categoria));
  cajaDetalle.appendChild(crearElemento('p', '', 'Ubicación aproximada: ' + objeto.ubicacion));
  cajaDetalle.appendChild(crearElemento('p', '', 'Fecha: ' + formatearFecha(objeto.fecha)));
  cajaDetalle.appendChild(crearElemento('p', '', 'Descripción: ' + (objeto.descripcion || 'Sin descripción.')));

  // Botones de acción: llevan al chat (pantalla 16) con el código del objeto
  const botones = crearElemento('div', 'botones');
  const coincide = crearElemento('a', 'boton verde', 'Coincide con lo mío');
  coincide.href = '16-chat.html?codigo=' + objeto.codigo;
  const abrirChat = crearElemento('a', 'boton secundario', 'Abrir chat');
  abrirChat.href = '16-chat.html?codigo=' + objeto.codigo;
  botones.appendChild(coincide);
  botones.appendChild(abrirChat);
  cajaDetalle.appendChild(botones);
}

// Busca el objeto: en el servidor (por id) o en los datos del navegador (por código)
async function cargarDetalle() {
  const id = obtenerParametro('id');

  if (id === null) {
    mostrarDetalle(buscarPorCodigo(obtenerObjetos(), obtenerParametro('codigo')));
    return;
  }

  cajaDetalle.innerHTML = '<p>Cargando…</p>';
  try {
    const respuesta = await fetch(URL_OBJETOS);
    if (!respuesta.ok) {
      throw new Error('Código ' + respuesta.status);
    }
    const objetos = await respuesta.json();

    let encontrado = null;
    for (let i = 0; i < objetos.length; i++) {
      if (String(objetos[i].id) === id) {
        encontrado = objetos[i];
      }
    }
    mostrarDetalle(encontrado);
  } catch (error) {
    cajaDetalle.innerHTML = '<p class="error">No se pudo conectar con el servidor. ¿Ejecutaste "node server.js"?</p>';
  }
}

cargarDetalle();
