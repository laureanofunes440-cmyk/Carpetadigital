# MZ Objetos Perdidos

HTML5, CSS3 y JavaScript clásico (solo `let` y `const`) en el frontend; Node.js + Express + MySQL en el backend.

## Archivos
```
BACKEND (carpeta principal del proyecto)
  database.sql     base mz_objetos_perdidos, tabla objetos y 2 registros de prueba
  conexion.js      conexión a MySQL (mysql2)
  ObjetoModel.js   clase ObjetoModel (POO) con obtenerTodos() y crear(): todas las consultas SQL
  server.js        servidor Express en http://127.0.0.1:3000 (CORS) con GET y POST /api/objetos
  package.json     dependencias: express, mysql2, cors

FRONTEND
  01-bienvenida.html ... 20-preceptoria.html     una pantalla por archivo
  css/styles.css
  js/               scripts de cada pantalla
```

## Puesta en marcha
1. Base de datos: `mysql -u root -p < database.sql`
2. En `conexion.js` cambiá `TU_CONTRASEÑA` por la contraseña de tu MySQL.
3. En la terminal de VS Code (dentro de la carpeta del proyecto): `npm install` y después `node server.js`
   Debe decir: "Conectado a MySQL correctamente" y "Servidor escuchando en http://127.0.0.1:3000".
4. Abrí `01-bienvenida.html` con Live Server (clic derecho > Open with Live Server).
5. Iniciá sesión con un correo `@ecmz.uncuyo.edu.ar` (cualquier contraseña). Para la pantalla 20, un correo que empiece con `preceptor`.

## Dónde se usa cada tema
- **POO:** `ObjetoModel.js` (clase con métodos estáticos `obtenerTodos` y `crear`).
- **Fetch API:** `js/muro.js` (GET), `js/reporte.js` (POST) y `js/detalle.js` (GET).
- **DOM:** `document.createElement`, `innerHTML` y `appendChild` en `js/muro.js` y `js/detalle.js`; lectura de campos con `querySelectorAll` en `js/reporte.js`.
- **BOM:** `window.location.href` (muro, reporte, menú) y `window.localStorage` (sesión, borrador del reporte y último código).

## Importante
Estas pantallas leen y escriben en MySQL: muro (03), detalle con `?id=` (04), reportes (07 a 14).
Estas otras todavía usan los datos guardados en el navegador: buscador (05), filtros (06), chat (16), marcar recuperado (17), perfil (18) y preceptoría (20).
