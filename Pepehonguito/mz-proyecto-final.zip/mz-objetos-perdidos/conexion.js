// ============================================================
//  conexion.js - Conexión a MySQL Community Server
// ============================================================

// Importamos la librería mysql2 (se instala con: npm install)
const mysql = require('mysql2');

// Datos para conectarnos a la base mz_objetos_perdidos
const conexion = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: 'TU_CONTRASEÑA',        // <-- poné acá la contraseña de tu MySQL
  database: 'mz_objetos_perdidos'
});

// Intentamos conectar y avisamos por consola si salió bien o mal
conexion.connect(function (error) {
  if (error) {
    console.log('Error al conectar con MySQL: ' + error.message);
    return;
  }
  console.log('Conectado a MySQL correctamente');
});

// Exportamos la conexión para usarla en ObjetoModel.js
module.exports = conexion;
