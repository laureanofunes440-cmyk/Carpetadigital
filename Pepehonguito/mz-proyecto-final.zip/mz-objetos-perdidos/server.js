// ============================================================
//  server.js - Servidor Express de MZ Objetos Perdidos
//  Instalar:  npm install
//  Ejecutar:  node server.js   ->   http://127.0.0.1:3000
// ============================================================

const express = require('express');
const cors = require('cors');
const ObjetoModel = require('./ObjetoModel');   // la clase con las consultas SQL

const app = express();
app.use(cors());           // permite que las páginas del sitio (otro origen) usen la API
app.use(express.json());   // permite leer los datos JSON que llegan en el POST

// Devuelve la fecha de hoy con formato AAAA-MM-DD
function hoy() {
  const f = new Date();
  const mes = String(f.getMonth() + 1).padStart(2, '0');
  const dia = String(f.getDate()).padStart(2, '0');
  return f.getFullYear() + '-' + mes + '-' + dia;
}

// ------------------------------------------------------------
//  GET /api/objetos -> lista de objetos
// ------------------------------------------------------------
app.get('/api/objetos', function (req, res) {
  ObjetoModel.obtenerTodos(function (error, objetos) {
    if (error) {
      console.log('Error al leer los objetos: ' + error.message);
      res.status(500).json({ error: 'No se pudieron obtener los objetos' });
      return;
    }
    res.json(objetos);
  });
});

// ------------------------------------------------------------
//  POST /api/objetos -> guarda un objeto nuevo
//  Datos (JSON): titulo, categoria, estado, ubicacion, fecha (opcional), descripcion (opcional)
// ------------------------------------------------------------
app.post('/api/objetos', function (req, res) {
  const datos = {
    titulo: req.body.titulo,
    categoria: req.body.categoria,
    estado: req.body.estado,
    ubicacion: req.body.ubicacion,
    fecha: req.body.fecha || hoy(),
    descripcion: req.body.descripcion || ''
  };

  // Revisamos que no falte ningún dato obligatorio
  if (!datos.titulo || !datos.categoria || !datos.estado || !datos.ubicacion) {
    res.status(400).json({ error: 'Faltan datos: titulo, categoria, estado y ubicacion' });
    return;
  }
  // Un reporte nuevo solo puede ser Perdido o Encontrado
  if (datos.estado !== 'Perdido' && datos.estado !== 'Encontrado') {
    res.status(400).json({ error: 'El estado debe ser Perdido o Encontrado' });
    return;
  }

  ObjetoModel.crear(datos, function (error, objeto) {
    if (error) {
      console.log('Error al guardar el objeto: ' + error.message);
      res.status(500).json({ error: 'No se pudo guardar el objeto' });
      return;
    }
    res.status(201).json(objeto);
  });
});

// ------------------------------------------------------------
//  Encendemos el servidor
// ------------------------------------------------------------
app.listen(3000, '127.0.0.1', function () {
  console.log('Servidor escuchando en http://127.0.0.1:3000');
});
