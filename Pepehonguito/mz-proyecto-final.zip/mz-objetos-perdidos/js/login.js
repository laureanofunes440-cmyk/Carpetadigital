// ============================================================
//  js/login.js - Pantalla 02: inicio de sesión (demostración)
// ============================================================

const formularioLogin = document.getElementById('formulario-login');
const mensajeError = document.getElementById('mensaje-error');

function mostrarError(texto) {
  mensajeError.textContent = texto;
  mensajeError.hidden = false;
}

// Se ejecuta cuando la persona aprieta "Iniciar sesión"
formularioLogin.addEventListener('submit', function (evento) {
  evento.preventDefault();   // evita que la página se recargue

  const correo = document.getElementById('correo').value.trim().toLowerCase();
  const clave = document.getElementById('clave').value;

  if (correo === '' || clave === '') {
    mostrarError('Escribí tu correo y tu contraseña.');
    return;
  }
  if (!correo.endsWith('@ecmz.uncuyo.edu.ar')) {
    mostrarError('Usá tu correo institucional (@ecmz.uncuyo.edu.ar).');
    return;
  }

  // Guardamos el correo en el navegador y pasamos al muro
  localStorage.setItem('usuario', correo);
  window.location.href = '03-muro.html';
});

// Enlace "¿Olvidaste tu acceso?"
document.getElementById('olvide').addEventListener('click', function (evento) {
  evento.preventDefault();
  alert('Pedile a Preceptoría que restablezca tu acceso.');
});
