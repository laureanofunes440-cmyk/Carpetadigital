// ============================================================
//  js/recuperado.js - Pantalla 17: marcar un objeto como recuperado
// ============================================================

const selectorObjeto = document.getElementById('selector-objeto');
const resumenObjeto = document.getElementById('resumen-objeto');
const casillaConfirmo = document.getElementById('casilla-confirmo');
const botonConfirmar = document.getElementById('boton-confirmar');
const formularioRecuperado = document.getElementById('formulario-recuperado');

// Llenamos la lista con los objetos que todavía no fueron recuperados
function llenarSelector() {
  const lista = obtenerObjetos();
  for (let i = 0; i < lista.length; i++) {
    if (lista[i].estado !== 'Recuperado') {
      const opcion = crearElemento('option', '', lista[i].codigo + ' · ' + lista[i].titulo);
      opcion.value = lista[i].codigo;
      selectorObjeto.appendChild(opcion);
    }
  }
  const elegido = obtenerParametro('codigo');
  if (elegido !== null) {
    selectorObjeto.value = elegido;
  }
}

// Muestra el resumen y habilita el botón solo si la casilla está marcada
function actualizarResumen() {
  const objeto = buscarPorCodigo(obtenerObjetos(), selectorObjeto.value);
  if (objeto === null) {
    resumenObjeto.textContent = 'No hay objetos pendientes.';
  } else {
    resumenObjeto.textContent = objeto.titulo + ' · ' + objeto.codigo + ' · ' + objeto.ubicacion;
  }
  botonConfirmar.disabled = (objeto === null || !casillaConfirmo.checked);
}

formularioRecuperado.addEventListener('submit', function (evento) {
  evento.preventDefault();
  const lista = obtenerObjetos();
  const objeto = buscarPorCodigo(lista, selectorObjeto.value);
  if (objeto === null) { return; }

  objeto.estado = 'Recuperado';
  guardarObjetos(lista);
  alert('¡Gracias por tu honestidad! El objeto quedó como recuperado.');
  window.location.href = '03-muro.html';
});

selectorObjeto.addEventListener('change', actualizarResumen);
casillaConfirmo.addEventListener('change', actualizarResumen);
llenarSelector();
actualizarResumen();
