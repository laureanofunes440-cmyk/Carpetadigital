// ============================================================
//  js/reporte.js - Pantallas 07 a 09 y 11 a 13: reportes en pasos
//  Cada paso guarda lo escrito en un "borrador" (localStorage).
//  El último paso envía todo al servidor con fetch() (método POST).
// ============================================================

const URL_OBJETOS = 'http://127.0.0.1:3000/api/objetos';
const formularioPaso = document.getElementById('formulario-paso');
const avisoPaso = document.getElementById('mensaje-error');

function mostrarAviso(texto) {
  avisoPaso.textContent = texto;
  avisoPaso.hidden = false;
}

// Envía el reporte completo al servidor
async function publicarReporte(borrador) {
  if (!borrador.titulo || !borrador.ubicacion) {
    alert('Faltan datos del reporte. Empecemos de nuevo.');
    window.location.href = formularioPaso.dataset.inicioUrl;   // BOM: cambia de página
    return;
  }

  // Los datos opcionales se juntan en la descripción
  const partes = [];
  if (borrador.color) { partes.push('Color o tipo: ' + borrador.color); }
  if (borrador.franja) { partes.push('Horario: ' + borrador.franja); }
  if (borrador.condicion) { partes.push('Estado del objeto: ' + borrador.condicion); }
  if (borrador.notas) { partes.push(borrador.notas); }

  // Objeto que viaja al servidor (se convierte a JSON)
  const reporte = {
    titulo: borrador.titulo,
    categoria: borrador.categoria,
    estado: borrador.estado,
    ubicacion: borrador.ubicacion,
    fecha: borrador.fecha || hoy(),
    descripcion: partes.join('. ')
  };

  const botonEnviar = formularioPaso.querySelector('button[type="submit"]');
  botonEnviar.disabled = true;   // evita enviar dos veces

  try {
    const respuesta = await fetch(URL_OBJETOS, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(reporte)
    });
    const creado = await respuesta.json();

    if (!respuesta.ok) {
      throw new Error(creado.error || 'Error del servidor');
    }

    // BOM: localStorage guarda el código y el id del reporte para las pantallas siguientes
    window.localStorage.setItem('ultimoCodigo', creado.codigo);
    window.localStorage.setItem('ultimoId', creado.id);
    const misCodigos = JSON.parse(window.localStorage.getItem('misCodigos') || '[]');
    misCodigos.push(creado.codigo);
    window.localStorage.setItem('misCodigos', JSON.stringify(misCodigos));
    window.localStorage.removeItem('borrador');

    // BOM: window.location.href lleva a la pantalla de confirmación
    window.location.href = formularioPaso.dataset.siguiente;
  } catch (error) {
    mostrarAviso('No se pudo publicar el reporte: ' + error.message + '. ¿Está encendido el servidor?');
    botonEnviar.disabled = false;
  }
}

// Se ejecuta cuando la persona aprieta "Siguiente" o "Publicar"
formularioPaso.addEventListener('submit', function (evento) {
  evento.preventDefault();   // evita que el formulario recargue la página

  // 1. Revisamos los campos obligatorios
  const obligatorios = formularioPaso.querySelectorAll('[required]');
  for (let i = 0; i < obligatorios.length; i++) {
    const campo = obligatorios[i];
    const vacio = (campo.type === 'checkbox') ? !campo.checked : campo.value.trim() === '';
    if (vacio) {
      mostrarAviso('Completá todos los campos obligatorios.');
      return;
    }
  }

  // 2. Leemos los campos del DOM y los sumamos al borrador (el primer paso empieza uno nuevo)
  let borrador = {};
  if (formularioPaso.dataset.inicio !== 'si') {
    borrador = JSON.parse(window.localStorage.getItem('borrador') || '{}');
  }
  const camposConNombre = formularioPaso.querySelectorAll('[name]');
  for (let j = 0; j < camposConNombre.length; j++) {
    borrador[camposConNombre[j].name] = camposConNombre[j].value.trim();
  }
  borrador.estado = formularioPaso.dataset.estado;
  window.localStorage.setItem('borrador', JSON.stringify(borrador));

  // 3. Último paso: enviar al servidor. Si no, ir al paso siguiente.
  if (formularioPaso.dataset.final === 'si') {
    publicarReporte(borrador);
  } else {
    window.location.href = formularioPaso.dataset.siguiente;
  }
});
