-- ============================================================
--  MZ Objetos Perdidos - Base de datos (MySQL)
--  Ejecutar completo:  mysql -u root -p < database.sql
--  OJO: borra la tabla "objetos" y la crea de nuevo con 2 registros de prueba.
-- ============================================================

CREATE DATABASE IF NOT EXISTS mz_objetos_perdidos;
USE mz_objetos_perdidos;

DROP TABLE IF EXISTS objetos;

CREATE TABLE objetos (
  id          INT AUTO_INCREMENT PRIMARY KEY,                       -- número que MySQL asigna solo
  codigo      VARCHAR(20) NOT NULL UNIQUE,                          -- MZ-P-0001 (perdido) o MZ-E-0001 (encontrado)
  titulo      VARCHAR(100) NOT NULL,                                -- nombre del objeto
  categoria   VARCHAR(50) NOT NULL,                                 -- Útiles, Tecnología, Indumentaria, Varios
  estado      ENUM('Perdido', 'Encontrado', 'Recuperado') NOT NULL, -- situación del objeto
  ubicacion   VARCHAR(100) NOT NULL,                                -- dónde se perdió o se encontró
  fecha       DATE NOT NULL,                                        -- día en que ocurrió
  descripcion TEXT                                                  -- detalles (color, horario, notas)
);

INSERT INTO objetos (codigo, titulo, categoria, estado, ubicacion, fecha, descripcion) VALUES
('MZ-P-0001', 'Calculadora científica Casio', 'Útiles',       'Perdido',    'Aula 204',      '2026-11-03', 'Calculadora gris con tapa. Atrás tiene mi nombre.'),
('MZ-E-0001', 'Campera de egresados',         'Indumentaria', 'Encontrado', 'Patio central', '2026-11-04', 'Campera azul con el año de la promoción bordado en la espalda.');
