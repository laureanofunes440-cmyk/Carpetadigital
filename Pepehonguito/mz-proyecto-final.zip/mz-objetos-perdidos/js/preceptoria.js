// ============================================================
//  js/preceptoria.js - Pantalla 20: panel de Preceptoría
// ============================================================

const cuerpoTabla = document.getElementById('tabla-pendientes');

// Valida la entrega de un objeto: pasa a "Recuperado"
function validarEntrega(codigo) {
  if (!confirm('¿Confirmás la entrega de ' + codigo + '? Pedí DNI o credencial.')) { return; }
  const lista = obtenerObjetos();
  const objeto = buscarPorCodigo(lista, codigo);
  objeto.estado = 'Recuperado';
  guardarObjetos(lista);
  dibujarPanel();
}

// Calcula las métricas y dibuja la tabla de objetos en resguardo
function dibujarPanel() {
  const lista = obtenerObjetos();
  let resguardo = 0;
  let entregados = 0;
  let perdidos = 0;
  cuerpoTabla.innerHTML = '';

  for (let i = 0; i < lista.length; i++) {
    const o = lista[i];
    if (o.estado === 'Recuperado') { entregados++; }
    if (o.estado === 'Perdido') { perdidos++; }
    if (o.estado === 'Encontrado') {
      resguardo++;
      const fila = document.createElement('tr');
      fila.appendChild(crearElemento('td', '', o.codigo));
      fila.appendChild(crearElemento('td', '', o.titulo));
      fila.appendChild(crearElemento('td', '', o.ubicacion));

      const celda = document.createElement('td');
      const boton = crearElemento('button', 'boton verde', 'Validar entrega');
      boton.addEventListener('click', function () { validarEntrega(o.codigo); });
      celda.appendChild(boton);
      fila.appendChild(celda);
      cuerpoTabla.appendChild(fila);
    }
  }
  if (resguardo === 0) {
    const vacia = document.createElement('tr');
    const celdaVacia = crearElemento('td', '', 'No hay objetos pendientes.');
    celdaVacia.colSpan = 4;
    vacia.appendChild(celdaVacia);
    cuerpoTabla.appendChild(vacia);
  }
  document.getElementById('cifra-resguardo').textContent = resguardo;
  document.getElementById('cifra-entregas').textContent = entregados;
  document.getElementById('cifra-perdidos').textContent = perdidos;
}

dibujarPanel();
